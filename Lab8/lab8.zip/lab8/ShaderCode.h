#ifndef SHADER_CODE
#define SHADER_CODE

#include <string>


const std::string shaderPhongVert = R"VERT(
#version 150
in vec4 vertPos;
in vec4 vertColor;
in vec4 vertNormal;
in vec4 vertTexCoord;

uniform mat4 rot;

out vec4 interpColor;
out vec4 interpNormal;
out vec2 interpTexCoord;

void main() {
    gl_Position = rot * vertPos;
    interpColor = vertColor;
    interpNormal = vertNormal;
    interpTexCoord = vertTexCoord.xy;
}
)VERT";




const std::string shaderPhongFrag = R"FRAG(
#version 150
out vec4 color;

in vec4 interpColor;
in vec4 interpNormal;
in vec2 interpTexCoord;

uniform vec4 eyePos;
uniform vec4 lightDirection;
uniform vec4 lightColor;
uniform vec4 ambientColor;

void main() {
    
    vec3 normal = normalize(interpNormal.xyz);
    vec3 light = normalize(lightDirection.xyz);
    vec3 toEye = normalize(eyePos.xyz);
    
    vec3 halfVec = normalize(toEye + light);
    
    float diffuseAmount = max(0.0, dot(normal, light));
    
    float specularAmount = pow(max(0.0, dot(halfVec,normal)), 2000.0);
    
    vec4 diffuseTerm = vec4(0.7, 0.5, 0.4, 1.0) * diffuseAmount + interpColor *ambientColor;
    vec4 specularTerm = vec4(10.0, 5.0, 2.0, 10.0) * specularAmount;
    diffuseTerm.a = 1.0;
    color = diffuseTerm + specularTerm;
}
)FRAG";



const std::string shaderHorizVert = R"VERT(
#version 150
in vec4 vertPos;
in vec4 vertTexCoord;

out vec2 interpTexCoord;

void main() {
    gl_Position = vertPos;
    interpTexCoord = vertTexCoord.xy;
}
)VERT";




const std::string shaderHorizFrag = R"FRAG(
#version 150
out vec4 color;

in vec2 interpTexCoord;

uniform sampler2D tex;
uniform float width;
uniform float height;

void main() {
    vec4 accum = vec4(0.0, 0.0, 0.0, 1.0);
    
    accum = texture(tex, interpTexCoord);
    
    accum.a = 1.0;
    color = accum;
}
)FRAG";

const std::string shaderVertVert = R"VERT(
#version 150
in vec4 vertPos;
in vec4 vertTexCoord;

out vec2 interpTexCoord;

void main() {
    gl_Position = vertPos;
    interpTexCoord = vertTexCoord.xy;
}
)VERT";




const std::string shaderVertFrag = R"FRAG(
#version 150
out vec4 color;

in vec2 interpTexCoord;

uniform sampler2D tex;
uniform float width;
uniform float height;

void main() {
    vec4 accum = vec4(0.0, 0.0, 0.0, 0.0);
    
    accum = texture(tex, interpTexCoord);
    
    accum.a = 1.0;
    color = accum;
}
)FRAG";

#endif