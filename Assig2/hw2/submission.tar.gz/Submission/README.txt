************************************************ HOMEWORK 2 ******************************************************

Evan Oman
CS 5721
3/24/2015

Explanation of External Resources:
- I used Wikipedia and Wolfram MathWorld to find equations for the parameterized surfaces used in this assignment.
- I used Mathematica to compute the normals for most of the surfaces used.

Files in this Directory:
- MeshBuilder.cpp: This is where I made changes to the original code to allow triangle stips, triangle loops, and 
	quad objects.
- hw2.cpp: This is the file where I made changes to the original code to use the MeshBuilder functionality in
	order to create a sphere, a torus, and and cone. This file also contains my position and normal functions.
* These are the only files that I needed to complete this assignment so these are the only files which I am 
	going to submit.